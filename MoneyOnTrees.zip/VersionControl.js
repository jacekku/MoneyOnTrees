let gameVersion=0.5
let resetAfterUpdate=true